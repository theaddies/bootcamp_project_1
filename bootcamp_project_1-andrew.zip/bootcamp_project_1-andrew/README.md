# bootcamp_project_1
Project to link national park hiking trail data with US census data
